#!/usr/bin/python

from mininet.net import Mininet
from mininet.node import Controller, RemoteController, OVSController
from mininet.node import Host, Node
from mininet.node import OVSKernelSwitch, UserSwitch
from mininet.node import IVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.link import TCLink, Intf
from subprocess import call
from mininet.term import makeTerm
import time
import subprocess

# Certificate generation
print("Generating certificate...")
subprocess.run(["sudo", "-E", "python3", "certificate_generation.py"])


def myNetwork():

    net = Mininet( topo=None,
                   build=False,
                   ipBase='10.0.0.0/24')

    info( '*** Adding controller\n' )
    c0=net.addController(name='c0',
                      controller=Controller,
                      protocol='tcp',
                      port=6633)

    info( '*** Add switches\n')
    s1 = net.addSwitch('s1', cls=OVSKernelSwitch)
    s2 = net.addSwitch('s2', cls=OVSKernelSwitch)

    r5 = net.addHost('r5', cls=Node, ip='10.0.2.1/24')
    r5.cmd('sysctl -w net.ipv4.ip_forward=1')
    r4 = net.addHost('r4', cls=Node, ip='192.168.1.2/30')   
    r4.cmd('sysctl -w net.ipv4.ip_forward=1')
    r3 = net.addHost('r3', cls=Node, ip='10.0.1.1/24')
    r3.cmd('sysctl -w net.ipv4.ip_forward=1')

    info( '*** Add hosts\n')
    h1 = net.addHost('h1', cls=Host, ip='10.0.1.2/24', defaultRoute='via 10.0.1.1')
    h2 = net.addHost('h2', cls=Host, ip='10.0.1.3/24', defaultRoute='via 10.0.1.1')
    h3 = net.addHost('h3', cls=Host, ip='10.0.2.2/24', defaultRoute='via 10.0.2.1')
    h4 = net.addHost('h4', cls=Host, ip='10.0.2.3/24', defaultRoute='via 10.0.2.1')

    info( '*** Add links\n')
    net.addLink(h1, s1)
    net.addLink(h2, s1)
    net.addLink(h3, s2)
    net.addLink(h4, s2)
    net.addLink(s2, r5)
    net.addLink(s1, r3)

    # Assigning IP addresses
    net.addLink(r3, r4, intfName1='r3-eth1', params1={'ip':'192.168.1.1/30'}, intfName2='r4-eth0', params2={'ip':'192.168.1.2/30'})
    net.addLink(r4, r5, intfName1='r4-eth1', params1={'ip':'192.168.2.1/30'}, intfName2='r5-eth1', params2={'ip':'192.168.2.2/30'})

    net.build()

    # Add static routes
    r3.cmd('ip route add 10.0.2.0/24 via 192.168.1.2')
    r3.cmd('ip route add 192.168.2.0/30 via 192.168.1.2')

    r4.cmd('ip route add 10.0.1.0/24 via 192.168.1.1')
    r4.cmd('ip route add 10.0.2.0/24 via 192.168.2.2')

    r5.cmd('ip route add 10.0.1.0/24 via 192.168.2.1')
    r5.cmd('ip route add 192.168.1.0/30 via 192.168.2.1')

    info( '*** Starting controllers\n')
    for controller in net.controllers:
        controller.start()
        
    s1.start([c0])
    s2.start([c0])
    
    info( '*** Post configure switches and hosts\n')
    time.sleep(0.1)         #delay to ensure proper start of Xterm terminal
    makeTerm(h4, title='Node', term='xterm', display=None, cmd='python3 tpa4_chat_server.py; bash')     #to start the server program in an Xterm terminal of host h4
    time.sleep(0.1)         #delay to ensure proper start of Xterm terminal
    makeTerm(h1, title='Node', term='xterm', display=None, cmd='python3 tpa4_chat_client.py; bash')     #to start the client program in an Xterm terminal of host h1
    time.sleep(0.1)         #delay to ensure proper start of Xterm terminal
    makeTerm(h2, title='Node', term='xterm', display=None, cmd='python3 tpa4_chat_client.py; bash')     #to start the client program in an Xterm terminal of host h2
    time.sleep(0.2)         #delay to ensure proper start of Xterm terminal
    makeTerm(h3, title='Node', term='xterm', display=None, cmd='python3 tpa4_chat_client.py; bash')     #to start the client program in an Xterm terminal of host h3

    CLI(net)
    net.stop()
    
    net.stopXterms()    #to ensure that the terminal windows are closed when exiting mininet

if __name__ == '__main__':
    setLogLevel('info')
    myNetwork()

