#!env python

"""Certificate Generation for CST311 Programming Assignment 4"""
__author__ = "Team 9"
__credits__ = [
    "Nicole Al-Sabah",
    "Deborah Shaw",
    "Aaron Berkness"
]

# Import statements
import os
import subprocess
import sys


def run_command(command):
    # Run a shell command and get the output
    output = subprocess.run(command, shell=True, text=True, capture_output=True)
    if output.returncode != 0:
        print(f"Error: {command} \n{output.stderr}")
        sys.exit(1)
    return output.stdout


def info_prompt():
    # Prompt input for information to generate certificates
    common_name = input("Enter the common name for the chat server: ")
    passphrase = input("Enter the passphrase for the Certificate Authority: ")

    information = {
        "Country": input("Enter the country code (2 letters): "),
        "State": input("Enter the state (full name): "),
        "Locality": input("Enter the city: "),
        "Organization": input("Enter the organization name: "),
        "Organizational Unit": input("Enter the organizational unit name: "),
        "Common Name": common_name,
        "Email": input("Enter the email address (optional): ")
    }

    # Write the common name to a text file
    with open("common_name.txt", "w") as f:
        f.write(common_name)

    print(f"Information collected for common name: {common_name}")
    return information, passphrase


def modify_hosts_file(common_name):
    # Add server IP addresses and common name to the /etc/ hosts file
    hosts_file = f"""
127.0.0.1\tlocalhost
127.0.1.1\tmininet-vm
10.0.2.3\t{common_name} # Server IP address (h4)
10.0.1.2\th1
10.0.1.3\th2
10.0.2.2\th3
"""
    print("Modifying /etc/hosts file...")
    with open("/etc/hosts", "a") as f:
        f.write(hosts_file)
    print("Hosts file modified.")


def ca_directories():
    # Create a directory structure for the Certificate Authority
    directories = [
        "/etc/ssl/demoCA",
        "/etc/ssl/demoCA/certs",
        "/etc/ssl/demoCA/newcerts",
        "/etc/ssl/demoCA/private"
    ]
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)


def initialize_ca():
    # Initialize files for the Certificate Authority
    open('/etc/ssl/demoCA/index.txt', 'w').close()
    with open('/etc/ssl/demoCA/serial', 'w') as f:
        f.write('1000\n')


def generate_root_key(passphrase):
    # Generate the Certificate Authority RSA private key
    run_command(f"sudo openssl genrsa -aes256 -out /etc/ssl/demoCA/private/cakey.pem -passout pass:{passphrase} 2048")


def generate_root_certificate(information, passphrase):
    # Generate the Certificate Authority self-signed certificate
    run_command(f"sudo openssl req -new -x509 -key /etc/ssl/demoCA/private/cakey.pem -passin pass:{passphrase} -out /etc/ssl/demoCA/cacert.pem -days 365 -subj '/C={information['Country']}/ST={information['State']}/L={information['Locality']}/O={information['Organization']}/OU={information['Organizational Unit']}/CN={information['Common Name']}'")


def generate_server_key():
    # Generate the server RSA private key
    run_command('sudo openssl genrsa -out /etc/ssl/demoCA/private/cst311.test-key.pem 2048')


def generate_server_csr(information):
    # Generate the server Certificate Signing Request
    run_command(f"sudo openssl req -new -key /etc/ssl/demoCA/private/cst311.test-key.pem -out /etc/ssl/demoCA/cst311.test.csr -subj '/C={information['Country']}/ST={information['State']}/L={information['Locality']}/O={information['Organization']}/OU={information['Organizational Unit']}/CN={information['Common Name']}'")


def generate_server_certificate(passphrase):
    # Use the root Certificate Authority to sign the server Certificate Signing Request
    command = f"""sudo openssl x509 -req -days 365 -in /etc/ssl/demoCA/cst311.test.csr -CA /etc/ssl/demoCA/cacert.pem -CAkey /etc/ssl/demoCA/private/cakey.pem -passin pass:{passphrase} -CAcreateserial -out /etc/ssl/demoCA/newcerts/cst311.test-cert.pem"""
    run_command(command)


def view_certificate():
    # View the server certificate
    print("Viewing the server certificate...")
    command = "sudo openssl x509 -text -noout -in /etc/ssl/demoCA/newcerts/cst311.test-cert.pem"
    output = run_command(command)
    print(output)


def main():
    # Run the certificate generation process
    information, passphrase = info_prompt()
    ca_directories()
    initialize_ca()
    generate_root_key(passphrase)
    generate_root_certificate(information, passphrase)
    generate_server_key()
    generate_server_csr(information)
    generate_server_certificate(passphrase)
    modify_hosts_file(information['Common Name'])
    print("Certificate generation complete.")
    view_certificate()


if __name__ == "__main__":
    main()
