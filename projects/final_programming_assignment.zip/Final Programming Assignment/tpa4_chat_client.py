#!env python

"""Chat client for CST311 Programming Assignment 4"""
__author__ = "Team 9"
__credits__ = [
  "Nicole Al-Sabah",
  "Deborah Shaw",
  "Aaron Berkness"
]

# Import statements
import curses
import socket as s
import sys
import threading

# Configure logging
import logging
logging.basicConfig()
log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

# Set global variables
server_ip = '10.0.2.3'
server_port = 12000

def clear_console():
  try:
    # initialize curses
    clear_window = curses.initscr()
    # clear window
    clear_window.clear()
    clear_window.refresh()
    # wait for user to hit enter to show terminal prompt
    clear_window.getkey()
  finally:
    # restore terminal to original settings
    curses.endwin()

def send_message(client_socket):
  username = input('Welcome to the chat! Please enter your username:\n')     #get username then send to server
  client_socket.send(username.encode())
  while True:
    message = input()
    if message.lower() == 'bye':     #type 'bye' to leave the chat
      client_socket.send(message.encode())
      client_socket.close()
      clear_console()           # Clear the console before closing the connection
      sys.exit()
    client_socket.send(message.encode())    #send message to server
    
def received_message(client_socket):
  while True:
    try:
      server_response = client_socket.recv(1024)        #receive message from server
      if not server_response:           #break loop if server closes connection
        #print("Server disconnected.")
        break
      server_response_decoded = server_response.decode() 
      print(server_response_decoded)
    except ConnectionResetError:
      #print("Server Reset.")
      break
    except ConnectionAbortedError:
      #print("Server Abortion.")
      break

def main():
  # Create socket
  client_socket = s.socket(s.AF_INET, s.SOCK_STREAM)
  
  try:
    # Establish TCP connection
    client_socket.connect((server_ip,server_port))
    
    #create and start threads to handle sending and receiving messages from server
    send_thread = threading.Thread(target=send_message, args=(client_socket,))
    send_thread.start()
    received_thread = threading.Thread(target=received_message, args=(client_socket,))
    received_thread.start()
    
    send_thread.join()      #wait for threads to finish before exiting main
    received_thread.join()
    
  finally:
    #close socket prior to exit
    client_socket.close()

# This helps shield code from running when we import the module
if __name__ == "__main__":
  main()